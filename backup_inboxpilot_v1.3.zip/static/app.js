const API_BASE = '';
let apiKey = localStorage.getItem('inboxpilot_api_key') || '';
let currentEmail = null;
let emails = [];
let queue = [];
let rangeInfo = null;

function getHeaders() {
    const headers = { 'Content-Type': 'application/json' };
    if (apiKey) {
        headers['X-API-Key'] = apiKey;
    }
    return headers;
}

async function apiCall(endpoint, options = {}) {
    const response = await fetch(API_BASE + endpoint, {
        ...options,
        headers: getHeaders()
    });
    
    if (response.status === 401) {
        showApiKeyModal();
        throw new Error('API Key required');
    }
    
    if (!response.ok) {
        const text = await response.text();
        throw new Error(text || response.statusText);
    }
    
    const contentType = response.headers.get('content-type');
    if (contentType && contentType.includes('application/json')) {
        return response.json();
    }
    return response.text();
}

function showToast(message, duration = 3000) {
    const existing = document.querySelector('.toast');
    if (existing) existing.remove();
    
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => toast.remove(), duration);
}

function showApiKeyModal() {
    document.getElementById('apiKeyModal').classList.remove('hidden');
}

function hideApiKeyModal() {
    document.getElementById('apiKeyModal').classList.add('hidden');
}

function saveApiKey() {
    const input = document.getElementById('apiKeyInput');
    apiKey = input.value.trim();
    localStorage.setItem('inboxpilot_api_key', apiKey);
    hideApiKeyModal();
    loadEmails();
}

function setLoading(element, loading) {
    if (loading) {
        element.innerHTML = '<div class="loading"><div class="spinner"></div>Carregando...</div>';
    }
}

function buildRangeParams() {
    const rangeType = document.getElementById('rangeSelect').value;
    let params = `range=${rangeType}`;
    
    if (rangeType === 'last_n_days') {
        const nDays = document.getElementById('nDaysInput')?.value || 7;
        params += `&n=${nDays}`;
    } else if (rangeType === 'custom') {
        const startDate = document.getElementById('startDateInput')?.value;
        const endDate = document.getElementById('endDateInput')?.value;
        if (startDate) params += `&start=${startDate}`;
        if (endDate) params += `&end=${endDate}`;
    }
    
    const unreadOnly = document.getElementById('unreadOnlyCheck')?.checked ? 1 : 0;
    params += `&unread_only=${unreadOnly}`;
    
    return params;
}

async function loadEmails() {
    const listEl = document.getElementById('emailList');
    setLoading(listEl, true);
    
    const rangeParams = buildRangeParams();
    const providers = Array.from(document.querySelectorAll('.provider-check:checked'))
        .map(cb => cb.value).join(',');
    const folders = Array.from(document.querySelectorAll('.folder-check:checked'))
        .map(cb => cb.value).join(',');
    
    try {
        const data = await apiCall(`/ui/messages?${rangeParams}&providers=${providers}&folders=${folders}&limit=50`);
        emails = data.items || [];
        rangeInfo = data.range_info;
        renderEmailList();
        updateRangeDisplay();
        updateStatus(`${data.counts.total} emails (${data.counts.unread} não lidos)`);
    } catch (err) {
        listEl.innerHTML = `<div class="loading">Erro: ${err.message}</div>`;
    }
}

function updateRangeDisplay() {
    const displayEl = document.getElementById('rangeDisplay');
    if (displayEl && rangeInfo) {
        displayEl.textContent = rangeInfo.description;
        displayEl.title = `${rangeInfo.start_local} → ${rangeInfo.end_local} (${rangeInfo.tz_name})`;
    }
}

function handleRangeChange() {
    const rangeType = document.getElementById('rangeSelect').value;
    const nDaysGroup = document.getElementById('nDaysGroup');
    const customGroup = document.getElementById('customDateGroup');
    
    if (nDaysGroup) {
        nDaysGroup.style.display = rangeType === 'last_n_days' ? 'flex' : 'none';
    }
    if (customGroup) {
        customGroup.style.display = rangeType === 'custom' ? 'flex' : 'none';
    }
    
    loadEmails();
}

function renderEmailList() {
    const listEl = document.getElementById('emailList');
    
    if (emails.length === 0) {
        listEl.innerHTML = '<div class="loading">Nenhum email encontrado</div>';
        return;
    }
    
    listEl.innerHTML = emails.map((email, idx) => `
        <div class="email-item ${currentEmail && currentEmail.key === email.key ? 'selected' : ''}" 
             onclick="selectEmail(${idx})">
            <div class="from">
                <span>${escapeHtml(email.from.split('<')[0].trim() || email.from)}</span>
                <span class="badge ${email.classification}">${email.classification}</span>
            </div>
            <div class="subject">${escapeHtml(email.subject)}</div>
            <div class="meta">
                <span>${email.provider}</span>
                <span>${email.folder}</span>
                ${email.has_draft ? '<span>📝 Rascunho</span>' : ''}
            </div>
        </div>
    `).join('');
}

async function selectEmail(idx) {
    currentEmail = emails[idx];
    renderEmailList();
    
    const detailEl = document.getElementById('emailDetail');
    setLoading(detailEl, true);
    
    try {
        const data = await apiCall(`/inbox/message/${encodeURIComponent(currentEmail.key)}`);
        currentEmail = { ...currentEmail, ...data };
        renderEmailDetail();
    } catch (err) {
        detailEl.innerHTML = `<div class="loading">Erro: ${err.message}</div>`;
    }
}

function renderEmailDetail() {
    const detailEl = document.getElementById('emailDetail');
    
    if (!currentEmail) {
        detailEl.innerHTML = '<div class="empty">Selecione um email</div>';
        detailEl.className = 'email-detail empty';
        return;
    }
    
    detailEl.className = 'email-detail';
    detailEl.innerHTML = `
        <div class="email-header">
            <h2>${escapeHtml(currentEmail.subject)}</h2>
            <div class="meta">
                <strong>De:</strong> ${escapeHtml(currentEmail.from)}<br>
                <strong>Data:</strong> ${currentEmail.date}<br>
                <strong>Pasta:</strong> ${currentEmail.folder} | 
                <strong>Provider:</strong> ${currentEmail.provider}
                <span class="badge ${currentEmail.classification}">${currentEmail.classification}</span>
            </div>
        </div>
        
        <div class="email-body">${escapeHtml(currentEmail.body || currentEmail.snippet || '')}</div>
        
        <div class="action-buttons">
            <button class="btn-primary" onclick="suggestReply()">Sugerir Resposta</button>
            <button class="btn-secondary" onclick="addToQueue('mark_read')">Marcar como Lido</button>
            <button class="btn-danger" onclick="addToQueue('delete')">Apagar</button>
            <button class="btn-secondary" onclick="addToQueue('skip')">Ignorar</button>
        </div>
        
        <div class="draft-section ${currentEmail.has_draft || currentEmail.draft ? '' : 'hidden'}" id="draftSection">
            <h3>Rascunho de Resposta</h3>
            <textarea id="draftText">${escapeHtml(currentEmail.draft || '')}</textarea>
            <div class="draft-actions">
                <button class="btn-success" onclick="addToQueue('send')">Adicionar à Fila: Enviar</button>
                <button class="btn-secondary" onclick="saveDraft()">Salvar Rascunho</button>
            </div>
        </div>
    `;
}

async function suggestReply() {
    if (!currentEmail) return;
    
    showToast('Gerando sugestão de resposta...');
    
    try {
        const data = await apiCall(`/inbox/message/${encodeURIComponent(currentEmail.key)}/suggest-reply`, {
            method: 'POST'
        });
        
        currentEmail.draft = data.draft;
        currentEmail.has_draft = true;
        
        const draftSection = document.getElementById('draftSection');
        draftSection.classList.remove('hidden');
        document.getElementById('draftText').value = data.draft;
        
        showToast(data.cached ? 'Rascunho carregado do cache' : 'Resposta gerada com sucesso');
    } catch (err) {
        showToast('Erro: ' + err.message);
    }
}

async function saveDraft() {
    if (!currentEmail) return;
    
    const draftText = document.getElementById('draftText').value;
    
    try {
        await apiCall(`/queue/add`, {
            method: 'POST',
            body: JSON.stringify({
                key: currentEmail.key,
                action: 'skip',
                reply: { body: draftText }
            })
        });
        
        showToast('Rascunho salvo');
    } catch (err) {
        showToast('Erro: ' + err.message);
    }
}

async function addToQueue(action) {
    if (!currentEmail) return;
    
    const payload = {
        key: currentEmail.key,
        action: action
    };
    
    if (action === 'send') {
        const draftText = document.getElementById('draftText')?.value;
        if (draftText) {
            payload.reply = { body: draftText };
        }
    }
    
    try {
        await apiCall('/queue/add', {
            method: 'POST',
            body: JSON.stringify(payload)
        });
        
        showToast(`Adicionado à fila: ${action}`);
        loadQueue();
    } catch (err) {
        showToast('Erro: ' + err.message);
    }
}

async function loadQueue() {
    try {
        const data = await apiCall('/queue');
        queue = data.items || [];
        renderQueue();
    } catch (err) {
        console.error('Queue load error:', err);
    }
}

function renderQueue() {
    const queueEl = document.getElementById('queueList');
    
    if (queue.length === 0) {
        queueEl.innerHTML = '<div class="loading">Fila vazia</div>';
        return;
    }
    
    queueEl.innerHTML = queue.map(item => `
        <div class="queue-item">
            <div class="action">${item.action}</div>
            <div class="subject">${escapeHtml(item.subject || item.key)}</div>
            <div class="meta">${item.provider}</div>
        </div>
    `).join('');
}

async function executeQueue() {
    if (queue.length === 0) {
        showToast('Fila vazia');
        return;
    }
    
    if (!confirm(`Executar ${queue.length} ações?`)) return;
    
    showToast('Executando fila...');
    
    try {
        const data = await apiCall('/queue/commit', { method: 'POST' });
        showToast(`Concluído: ${data.summary.sent} enviados, ${data.summary.deleted} apagados`);
        loadQueue();
        loadEmails();
    } catch (err) {
        showToast('Erro: ' + err.message);
    }
}

async function exportChatGPT() {
    const range = document.getElementById('rangeSelect').value;
    const providers = Array.from(document.querySelectorAll('.provider-check:checked'))
        .map(cb => cb.value).join(',');
    const folders = Array.from(document.querySelectorAll('.folder-check:checked'))
        .map(cb => cb.value).join(',');
    
    try {
        const text = await apiCall(`/export/chatgpt?range=${range}&providers=${providers}&folders=${folders}`);
        await navigator.clipboard.writeText(text);
        showToast('Resumo copiado para a área de transferência!');
    } catch (err) {
        showToast('Erro: ' + err.message);
    }
}

async function exportDispatch() {
    try {
        const data = await apiCall('/export/dispatch.json');
        const text = JSON.stringify(data, null, 2);
        await navigator.clipboard.writeText(text);
        showToast('JSON de despacho copiado!');
    } catch (err) {
        showToast('Erro: ' + err.message);
    }
}

function switchTab(tabName) {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelector(`.tab[data-tab="${tabName}"]`).classList.add('active');
    
    document.querySelectorAll('.tab-content').forEach(c => c.classList.add('hidden'));
    document.getElementById(`${tabName}Tab`).classList.remove('hidden');
    
    if (tabName === 'queue') loadQueue();
}

function updateStatus(message) {
    document.getElementById('statusText').textContent = message;
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

async function executeImport(dryRun) {
    const input = document.getElementById('importJsonInput').value.trim();
    const resultEl = document.getElementById('importResult');
    
    if (!input) {
        resultEl.innerHTML = '<span style="color:red;">Cole o JSON primeiro</span>';
        return;
    }
    
    let payload;
    try {
        payload = JSON.parse(input);
    } catch (e) {
        resultEl.innerHTML = '<span style="color:red;">JSON invalido: ' + e.message + '</span>';
        return;
    }
    
    payload.dry_run = dryRun;
    
    try {
        const data = await apiCall('/dispatch/import', {
            method: 'POST',
            body: JSON.stringify(payload)
        });
        
        let html = '<div style="margin-bottom:8px;">';
        html += dryRun ? '<b>SIMULACAO:</b>' : '<b>EXECUTADO:</b>';
        html += '</div>';
        
        if (data.counts) {
            const c = data.counts;
            html += `<div>Acoes: send=${c.send||0}, delete=${c.delete||0}, mark_read=${c.mark_read||0}, skip=${c.skip||0}</div>`;
        }
        
        if (data.compose_counts) {
            const cc = data.compose_counts;
            html += `<div>Emails novos: enviados=${cc.sent||0}, erros=${cc.errors||0}</div>`;
        }
        
        if (data.compose_results && data.compose_results.length > 0) {
            html += '<div style="margin-top:8px;"><b>Compose:</b></div>';
            data.compose_results.forEach(r => {
                const color = r.status === 'sent' ? 'green' : (r.status === 'error' ? 'red' : 'orange');
                html += `<div style="color:${color};">${r.provider}: ${r.to} - ${r.status}</div>`;
            });
        }
        
        if (data.results && data.results.length > 0) {
            html += '<div style="margin-top:8px;"><b>Acoes:</b></div>';
            data.results.forEach(r => {
                const color = r.status === 'done' ? 'green' : (r.status === 'error' ? 'red' : 'orange');
                html += `<div style="color:${color};">${r.key}: ${r.decision} - ${r.status}</div>`;
            });
        }
        
        if ((!data.results || data.results.length === 0) && (!data.compose_results || data.compose_results.length === 0)) {
            html += '<div>Nenhuma acao no JSON</div>';
        }
        
        resultEl.innerHTML = html;
        
        if (!dryRun) {
            showToast('Import executado!');
            loadEmails();
        }
    } catch (err) {
        resultEl.innerHTML = '<span style="color:red;">Erro: ' + err.message + '</span>';
    }
}

document.addEventListener('DOMContentLoaded', () => {
    handleRangeChange();
    loadQueue();
    
    document.getElementById('refreshBtn').addEventListener('click', loadEmails);
    document.getElementById('executeQueueBtn').addEventListener('click', executeQueue);
    document.getElementById('exportChatGPTBtn').addEventListener('click', exportChatGPT);
    document.getElementById('exportDispatchBtn').addEventListener('click', exportDispatch);
    document.getElementById('saveApiKeyBtn').addEventListener('click', saveApiKey);
    document.getElementById('cancelApiKeyBtn').addEventListener('click', hideApiKeyModal);
    document.getElementById('importDryRunBtn').addEventListener('click', () => executeImport(true));
    document.getElementById('importExecuteBtn').addEventListener('click', () => executeImport(false));
    
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => switchTab(tab.dataset.tab));
    });
    
    document.querySelectorAll('.provider-check, .folder-check').forEach(cb => {
        cb.addEventListener('change', loadEmails);
    });
    
    document.getElementById('rangeSelect').addEventListener('change', handleRangeChange);
    
    const nDaysInput = document.getElementById('nDaysInput');
    if (nDaysInput) nDaysInput.addEventListener('change', loadEmails);
    
    const startDateInput = document.getElementById('startDateInput');
    const endDateInput = document.getElementById('endDateInput');
    if (startDateInput) startDateInput.addEventListener('change', loadEmails);
    if (endDateInput) endDateInput.addEventListener('change', loadEmails);
    
    const unreadOnlyCheck = document.getElementById('unreadOnlyCheck');
    if (unreadOnlyCheck) unreadOnlyCheck.addEventListener('change', loadEmails);
});
