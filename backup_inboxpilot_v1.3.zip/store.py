import json
import os
import sqlite3
import logging
from pathlib import Path
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

TOKEN_PATH = Path("token_cache.json")
DATABASE_URL = os.environ.get("DATABASE_URL")
SQLITE_PATH = Path("automation.db")

def _get_pg_conn():
    if not DATABASE_URL:
        return None
    import psycopg2
    return psycopg2.connect(DATABASE_URL)

def _init_kv_table():
    conn = _get_pg_conn()
    if not conn:
        return
    try:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS key_value_store (
                key TEXT PRIMARY KEY,
                value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
        cursor.close()
        conn.close()
    except Exception as e:
        logger.error(f"KV table init error: {e}")


def get_auth_token(provider: str) -> Tuple[Optional[str], str]:
    """
    Get auth token for a provider with fallback.
    Returns (token_json, source) where source is 'postgresql', 'file', or 'none'.
    """
    key = f"{provider}_token"
    
    conn = _get_pg_conn()
    if conn:
        try:
            _init_kv_table()
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM key_value_store WHERE key = %s", (key,))
            row = cursor.fetchone()
            cursor.close()
            conn.close()
            if row and row[0]:
                logger.debug(f"Token for {provider} loaded from PostgreSQL")
                return row[0], "postgresql"
        except Exception as e:
            logger.error(f"PostgreSQL get error for {provider}: {e}")
    
    try:
        if TOKEN_PATH.exists():
            cache = json.loads(TOKEN_PATH.read_text())
            if key in cache and cache[key]:
                logger.debug(f"Token for {provider} loaded from file fallback")
                return cache[key], "file"
    except Exception as e:
        logger.error(f"File fallback get error for {provider}: {e}")
    
    return None, "none"


def set_auth_token(provider: str, token_json: str) -> bool:
    """
    Save auth token to BOTH PostgreSQL and file fallback.
    Returns True if at least one storage succeeded.
    """
    key = f"{provider}_token"
    pg_ok = False
    file_ok = False
    
    conn = _get_pg_conn()
    if conn:
        try:
            _init_kv_table()
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO key_value_store (key, value, updated_at)
                VALUES (%s, %s, CURRENT_TIMESTAMP)
                ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = CURRENT_TIMESTAMP
            """, (key, token_json))
            conn.commit()
            cursor.close()
            conn.close()
            pg_ok = True
            logger.info(f"Token for {provider} saved to PostgreSQL")
        except Exception as e:
            logger.error(f"PostgreSQL set error for {provider}: {e}")
    
    try:
        cache = {}
        if TOKEN_PATH.exists():
            cache = json.loads(TOKEN_PATH.read_text())
        cache[key] = token_json
        TOKEN_PATH.write_text(json.dumps(cache))
        file_ok = True
        logger.info(f"Token for {provider} saved to file fallback")
    except Exception as e:
        logger.error(f"File fallback set error for {provider}: {e}")
    
    return pg_ok or file_ok


def get_storage_info() -> dict:
    """Get storage diagnostic info"""
    pg_available = False
    conn = _get_pg_conn()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            cursor.close()
            conn.close()
            pg_available = True
        except:
            pass
    
    return {
        "postgresql_available": pg_available,
        "postgresql_url_set": bool(DATABASE_URL),
        "file_path": str(TOKEN_PATH),
        "file_exists": TOKEN_PATH.exists()
    }

def load_cache() -> dict:
    if TOKEN_PATH.exists():
        return json.loads(TOKEN_PATH.read_text())
    return {}

def save_cache(cache: dict) -> None:
    TOKEN_PATH.write_text(json.dumps(cache))

def get_item(key: str, default=None):
    conn = _get_pg_conn()
    if conn:
        try:
            _init_kv_table()
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM key_value_store WHERE key = %s", (key,))
            row = cursor.fetchone()
            cursor.close()
            conn.close()
            if row:
                return row[0]
            return default
        except Exception as e:
            print(f"DB get error: {e}")
    return load_cache().get(key, default)

def set_item(key: str, value):
    conn = _get_pg_conn()
    if conn:
        try:
            _init_kv_table()
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO key_value_store (key, value, updated_at)
                VALUES (%s, %s, CURRENT_TIMESTAMP)
                ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = CURRENT_TIMESTAMP
            """, (key, value))
            conn.commit()
            cursor.close()
            conn.close()
        except Exception as e:
            print(f"DB set error: {e}")
    cache = load_cache()
    cache[key] = value
    save_cache(cache)


# =========================
# Gmail Token Storage (SQLite - automation.db)
# =========================

def _get_sqlite_conn():
    """Get SQLite connection to automation.db"""
    return sqlite3.connect(str(SQLITE_PATH))


def _init_gmail_tokens_table():
    """Create gmail_tokens table if not exists"""
    conn = _get_sqlite_conn()
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS gmail_tokens (
            email TEXT PRIMARY KEY DEFAULT 'default',
            access_token TEXT,
            refresh_token TEXT,
            scope TEXT,
            token_type TEXT DEFAULT 'Bearer',
            expiry_ts INTEGER,
            client_id TEXT,
            client_secret TEXT,
            needs_reauth INTEGER DEFAULT 0,
            last_refresh_error TEXT,
            updated_at INTEGER
        )
    """)
    conn.commit()
    cursor.close()
    conn.close()


def get_gmail_token() -> Optional[dict]:
    """
    Get Gmail token from SQLite with fallback migration from PostgreSQL/file.
    Returns dict with all token fields or None.
    """
    try:
        _init_gmail_tokens_table()
        conn = _get_sqlite_conn()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT access_token, refresh_token, scope, token_type, 
                   expiry_ts, client_id, client_secret, needs_reauth, 
                   last_refresh_error, updated_at, email
            FROM gmail_tokens
            WHERE email = 'default'
        """)
        row = cursor.fetchone()
        cursor.close()
        conn.close()
        
        if row and row[1]:
            return {
                "access_token": row[0],
                "refresh_token": row[1],
                "scope": row[2],
                "token_type": row[3],
                "expiry_ts": row[4],
                "client_id": row[5],
                "client_secret": row[6],
                "needs_reauth": bool(row[7]),
                "last_refresh_error": row[8],
                "updated_at": row[9],
                "email": row[10],
                "storage_source": "sqlite"
            }
        
        legacy_json, legacy_source = get_auth_token("gmail")
        if legacy_json:
            try:
                import json
                legacy_data = json.loads(legacy_json)
                if legacy_data.get("refresh_token"):
                    logger.info(f"Migrating Gmail token from {legacy_source} to SQLite")
                    
                    scopes = legacy_data.get("scopes", [])
                    scope_str = ' '.join(scopes) if isinstance(scopes, list) else str(scopes)
                    
                    set_gmail_token(
                        access_token=legacy_data.get("token"),
                        refresh_token=legacy_data.get("refresh_token"),
                        scope=scope_str,
                        expiry_ts=legacy_data.get("expiry_ts"),
                        client_id=legacy_data.get("client_id"),
                        client_secret=legacy_data.get("client_secret"),
                        needs_reauth=legacy_data.get("needs_reauth", False),
                        preserve_refresh_token=True
                    )
                    
                    return {
                        "access_token": legacy_data.get("token"),
                        "refresh_token": legacy_data.get("refresh_token"),
                        "scope": scope_str,
                        "expiry_ts": legacy_data.get("expiry_ts"),
                        "client_id": legacy_data.get("client_id"),
                        "client_secret": legacy_data.get("client_secret"),
                        "needs_reauth": legacy_data.get("needs_reauth", False),
                        "last_refresh_error": None,
                        "updated_at": legacy_data.get("updated_at"),
                        "storage_source": f"migrated_from_{legacy_source}"
                    }
            except Exception as e:
                logger.error(f"Error migrating legacy Gmail token: {e}")
        
        return None
    except Exception as e:
        logger.error(f"SQLite get gmail token error: {e}")
        return None


def set_gmail_token(
    access_token: str = None,
    refresh_token: str = None,
    scope: str = None,
    expiry_ts: int = None,
    client_id: str = None,
    client_secret: str = None,
    needs_reauth: bool = None,
    last_refresh_error: str = None,
    preserve_refresh_token: bool = True
) -> bool:
    """
    Update Gmail token in SQLite.
    Only updates fields that are provided (not None).
    If preserve_refresh_token=True and refresh_token=None, keeps existing refresh_token.
    """
    import time
    try:
        _init_gmail_tokens_table()
        conn = _get_sqlite_conn()
        cursor = conn.cursor()
        
        # Check if row exists
        cursor.execute("SELECT refresh_token FROM gmail_tokens WHERE email = 'default'")
        existing = cursor.fetchone()
        
        if existing:
            # Build UPDATE query with only provided fields
            updates = []
            values = []
            
            if access_token is not None:
                updates.append("access_token = ?")
                values.append(access_token)
            
            # Only update refresh_token if provided (preserve existing if None)
            if refresh_token is not None:
                updates.append("refresh_token = ?")
                values.append(refresh_token)
            elif not preserve_refresh_token:
                updates.append("refresh_token = ?")
                values.append(None)
            
            if scope is not None:
                updates.append("scope = ?")
                values.append(scope)
            
            if expiry_ts is not None:
                updates.append("expiry_ts = ?")
                values.append(expiry_ts)
            
            if client_id is not None:
                updates.append("client_id = ?")
                values.append(client_id)
            
            if client_secret is not None:
                updates.append("client_secret = ?")
                values.append(client_secret)
            
            if needs_reauth is not None:
                updates.append("needs_reauth = ?")
                values.append(1 if needs_reauth else 0)
            
            if last_refresh_error is not None:
                updates.append("last_refresh_error = ?")
                values.append(last_refresh_error)
            elif needs_reauth is False:
                # Clear error when reauth is cleared
                updates.append("last_refresh_error = ?")
                values.append(None)
            
            updates.append("updated_at = ?")
            values.append(int(time.time()))
            
            if updates:
                sql = f"UPDATE gmail_tokens SET {', '.join(updates)} WHERE email = 'default'"
                cursor.execute(sql, values)
        else:
            # Insert new row
            cursor.execute("""
                INSERT INTO gmail_tokens (
                    email, access_token, refresh_token, scope, expiry_ts,
                    client_id, client_secret, needs_reauth, last_refresh_error, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                'default',
                access_token,
                refresh_token,
                scope,
                expiry_ts,
                client_id,
                client_secret,
                1 if needs_reauth else 0,
                last_refresh_error,
                int(time.time())
            ))
        
        conn.commit()
        cursor.close()
        conn.close()
        logger.info("Gmail token saved to SQLite")
        return True
    except Exception as e:
        logger.error(f"SQLite set gmail token error: {e}")
        return False


def clear_gmail_refresh_error() -> bool:
    """Clear the last_refresh_error and needs_reauth flags"""
    return set_gmail_token(needs_reauth=False, last_refresh_error=None)
