# InboxPilot v1.3

## Overview

InboxPilot is a FastAPI-based email assistant application designed to streamline email management across multiple providers. It integrates with Microsoft Outlook, Apple Mail, and Gmail to fetch unread emails, generate AI-powered reply suggestions using OpenAI's GPT, and perform email actions such as marking as read and deleting. The project aims to provide intelligent email automation, a unified inbox, and a web-based dashboard for efficient email handling.

**Version 1.1 Features:**
- Session-based email collection with `/session/start`
- Chat/Travel mode with copy-paste workflow for ChatGPT integration
- Batch action execution with two-step delete safety
- Complete web dashboard at `/dashboard`
- Provider status page at `/setup`
- PDF Export for offline/ChatGPT workflow (`GET /export/pdf`)
- Dispatch Import for executing LLM-generated action plans (`POST /dispatch/import`)
- Enhanced date filters: today, current_week (Mon-Sun), current_month (1st-now), rolling week/month, custom range
- Unified session-based exports: Dashboard, PDF, and TXT exports all use identical session data
- Compose and send new emails via Apple Mail or Gmail (`POST /compose/{provider}`)

**Version 1.2 - Robust Apple IMAP (Jan 2026):**
- Robust UID-based IMAP fetch with batching and cutoff (`apple_imap.py`)
- Timezone-aware date filters using America/Sao_Paulo (`time_filters.py`)
- Unseen boost with priority partitioning: in-range unseen emails are never dropped
- Lightweight preview fetch using BODY.PEEK[TEXT]<0.500> to minimize IMAP load
- Proper naive datetime handling: interpreted as America/Sao_Paulo and converted to UTC

**Version 1.3 - Unified Date Filtering (Jan 2026):**
- Unified `build_date_range()` function in `time_filters.py` with consistent behavior
- New endpoint `GET /ui/messages` for unified message listing (Dashboard, PDF, GPT)
- Date range options:
  - `today`: 00:00-23:59 local time (America/Sao_Paulo)
  - `current_week`: Monday 00:00 → Sunday 23:59 (calendar week, NOT rolling)
  - `last_n_days`: now - N days (configurable 1-60)
  - `custom`: user-provided start/end dates with validation (max 90 days)
- Range info returned with every query (description, tz, start/end UTC/local)
- Dashboard UI updated with new range selector and "Só não lidos" checkbox
- Gmail tokens now stored in SQLite with auto-migration from legacy storage
- Gmail delete uses `messages().trash()` for safe deletion to Trash folder
- 22 unit tests for date filtering (all passing)

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

InboxPilot utilizes a pluggable provider layer architecture, abstracting email service integrations behind a common interface (`EmailProvider`). This allows for easy addition of new email providers. The core application is built with FastAPI, leveraging its asynchronous capabilities and automatic API documentation generation.

**Key Architectural Patterns:**

-   **Provider Abstraction:** An `EmailProvider` Abstract Base Class defines a contract for email operations, with concrete implementations for Apple Mail, Microsoft Outlook, and Gmail. This ensures modularity and extensibility.
-   **Modular Structure:** The codebase is organized into distinct modules for concerns like LLM integration (`llm.py`), HTTP wrappers (`graph.py`), and utility functions.
-   **Environment-based Configuration:** All sensitive information and configurations are managed via environment variables.

**UI/UX Decisions:**

-   A web-based dashboard is provided at `/dashboard` (and `/ui`) for email management, featuring an email list, detail view, queue management, and Chat/Travel mode integration. It's built using vanilla HTML/CSS/JS for simplicity.
-   Dashboard supports two operation modes: visual clicking and JSON import/export for ChatGPT workflow.

**Technical Implementations:**

-   **Backend Framework:** FastAPI (Python) for building robust RESTful APIs.
-   **Email Integrations:**
    -   **Microsoft Outlook:** Uses Microsoft Graph API v1.0 with OAuth 2.0 via MSAL.
    -   **Apple Mail:** Communicates via IMAP for reading and SMTP for sending, using app-specific passwords.
    -   **Gmail:** Integrates with Gmail API v1 using OAuth 2.0 via `google-auth-oauthlib`.
-   **Unified Endpoints:** A set of provider-agnostic endpoints (`/unified/*`) allows interaction with any configured email provider consistently.
-   **Automation Engine:** Configurable automation (`/automation/*`) based on `policy.json` allows for rule-based email processing (e.g., auto-reply, auto-delete) with dry-run, send-only, and full execution modes. All actions are audited in an SQLite database (`automation.db`).
-   **Assistant Loop:** Endpoints (`/assistant/*`) support human-in-the-loop workflows for classifying and acting on emails, with idempotency handled via SQLite tracking.
-   **Unified Inbox API:** Aggregates emails from all configured providers into a single view with range filtering (`/inbox/*`).
-   **Queue System:** Manages batch email actions (send, delete, mark_read) via `/queue/*` endpoints, allowing actions to be added and committed in bulk.
-   **Export Endpoints:** Provides functionality to export emails in formats suitable for external tools:
    -   `GET /export/pdf`: Generates a PDF with emails for offline analysis or ChatGPT input
    -   `POST /dispatch/import`: Imports and executes action plans from LLM responses (supports dry_run, two-step delete, idempotency)
    -   `GET /dispatch/example`: Returns a sample dispatch JSON template
-   **AI Integration:** Leverages OpenAI's GPT models for generating email summaries, priority classifications, and suggested replies, with responses tailored to Portuguese (Brazilian).

**Data Storage:**
-   Token caches for OAuth providers are stored in local JSON files.
-   Email drafts are persisted using a file-based key-value store.
-   Audit logs for automation are stored in an SQLite database (`automation.db`).

## External Dependencies

**APIs and Services:**

-   **Microsoft Graph API:** Used for interacting with Microsoft Outlook email services.
-   **OpenAI API:** Utilized for AI-powered email analysis and reply generation.
-   **Apple iCloud IMAP/SMTP:** Protocols used for Apple Mail operations.
-   **Gmail API:** Google's API for managing Gmail accounts.

**Python Packages:**

-   `fastapi`: Web framework.
-   `uvicorn`: ASGI server.
-   `msal`: Microsoft Authentication Library for OAuth 2.0.
-   `requests`: HTTP client for general API calls.
-   `python-dotenv`: For loading environment variables.
-   `google-auth`, `google-auth-oauthlib`, `google-api-python-client`: For Gmail OAuth and API interactions.
-   `pytest`, `httpx`: For testing purposes.
-   `imaplib`, `smtplib`: Python's standard libraries for IMAP and SMTP protocols.
-   `reportlab`: PDF generation library for export functionality.