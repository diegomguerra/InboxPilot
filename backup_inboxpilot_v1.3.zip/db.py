import sqlite3
import json
import hashlib
from datetime import datetime
from typing import Optional, List, Dict, Any

DB_PATH = "automation.db"


def _get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = _get_conn()
    cursor = conn.cursor()
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            key TEXT PRIMARY KEY,
            provider TEXT NOT NULL,
            msg_id TEXT NOT NULL,
            folder TEXT,
            from_addr TEXT,
            subject TEXT,
            date TEXT,
            body_hash TEXT,
            body_text TEXT,
            status TEXT DEFAULT 'new',
            category TEXT,
            priority TEXT,
            created_ts TEXT,
            updated_ts TEXT,
            session_id TEXT
        )
    """)
    
    try:
        cursor.execute("ALTER TABLE messages ADD COLUMN body_text TEXT")
    except:
        pass
    
    try:
        cursor.execute("ALTER TABLE messages ADD COLUMN session_id TEXT")
    except:
        pass
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS drafts (
            key TEXT PRIMARY KEY,
            draft_text TEXT,
            created_ts TEXT
        )
    """)
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS actions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key TEXT,
            provider TEXT,
            msg_id TEXT,
            action TEXT NOT NULL,
            status TEXT NOT NULL,
            reason TEXT,
            meta_json TEXT,
            ts TEXT NOT NULL,
            session_id TEXT
        )
    """)
    
    try:
        cursor.execute("ALTER TABLE actions ADD COLUMN session_id TEXT")
    except:
        pass
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT NOT NULL,
            provider TEXT NOT NULL,
            msg_id TEXT NOT NULL,
            action TEXT NOT NULL,
            status TEXT NOT NULL,
            reason TEXT,
            meta TEXT
        )
    """)
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            id TEXT PRIMARY KEY,
            created_at TEXT NOT NULL,
            providers TEXT,
            folders TEXT,
            range_filter TEXT,
            from_date TEXT,
            to_date TEXT,
            status TEXT DEFAULT 'open'
        )
    """)
    
    try:
        cursor.execute("ALTER TABLE sessions ADD COLUMN from_date TEXT")
    except:
        pass
    
    try:
        cursor.execute("ALTER TABLE sessions ADD COLUMN to_date TEXT")
    except:
        pass
    
    try:
        cursor.execute("ALTER TABLE sessions ADD COLUMN date_mode TEXT")
    except:
        pass
    
    try:
        cursor.execute("ALTER TABLE sessions ADD COLUMN rolling_days INTEGER")
    except:
        pass
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS session_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            key TEXT NOT NULL,
            provider TEXT,
            message_id TEXT,
            date TEXT,
            classification TEXT,
            subject TEXT,
            sender TEXT,
            UNIQUE(session_id, key)
        )
    """)
    
    conn.commit()
    conn.close()


def make_key(provider: str, msg_id: str) -> str:
    return f"{provider}:{msg_id}"


def body_hash(body: str) -> str:
    return hashlib.md5(body.encode('utf-8', errors='ignore')).hexdigest()[:16]


def upsert_message(
    key: str,
    provider: str,
    msg_id: str,
    folder: str = None,
    from_addr: str = None,
    subject: str = None,
    date: str = None,
    body: str = None,
    status: str = "new",
    category: str = None,
    priority: str = None
) -> bool:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    now = datetime.utcnow().isoformat()
    
    cursor.execute("SELECT key, status FROM messages WHERE key = ?", (key,))
    existing = cursor.fetchone()
    
    if existing:
        if existing["status"] in ("sent", "deleted"):
            conn.close()
            return False
        
        cursor.execute("""
            UPDATE messages SET
                folder = COALESCE(?, folder),
                from_addr = COALESCE(?, from_addr),
                subject = COALESCE(?, subject),
                date = COALESCE(?, date),
                body_hash = COALESCE(?, body_hash),
                body_text = COALESCE(?, body_text),
                status = COALESCE(?, status),
                category = COALESCE(?, category),
                priority = COALESCE(?, priority),
                updated_ts = ?
            WHERE key = ?
        """, (folder, from_addr, subject, date, body_hash(body) if body else None,
              body, status, category, priority, now, key))
    else:
        cursor.execute("""
            INSERT INTO messages (key, provider, msg_id, folder, from_addr, subject, date, body_hash, body_text, status, category, priority, created_ts, updated_ts)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (key, provider, msg_id, folder, from_addr, subject, date, 
              body_hash(body) if body else None, body, status, category, priority, now, now))
    
    conn.commit()
    conn.close()
    return True


def get_message(key: str) -> Optional[Dict]:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM messages WHERE key = ?", (key,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def mark_status(key: str, status: str) -> bool:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    now = datetime.utcnow().isoformat()
    cursor.execute("UPDATE messages SET status = ?, updated_ts = ? WHERE key = ?", (status, now, key))
    affected = cursor.rowcount
    conn.commit()
    conn.close()
    return affected > 0


def set_draft(key: str, text: str) -> bool:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    now = datetime.utcnow().isoformat()
    cursor.execute("""
        INSERT OR REPLACE INTO drafts (key, draft_text, created_ts)
        VALUES (?, ?, ?)
    """, (key, text, now))
    conn.commit()
    conn.close()
    return True


def get_draft(key: str) -> Optional[str]:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    cursor.execute("SELECT draft_text FROM drafts WHERE key = ?", (key,))
    row = cursor.fetchone()
    conn.close()
    return row["draft_text"] if row else None


def log_action(
    key: str,
    provider: str,
    msg_id: str,
    action: str,
    status: str,
    reason: str = "",
    meta: dict = None
) -> int:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    now = datetime.utcnow().isoformat()
    cursor.execute("""
        INSERT INTO actions (key, provider, msg_id, action, status, reason, meta_json, ts)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (key, provider, msg_id, action, status, reason, json.dumps(meta or {}), now))
    action_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return action_id


def list_logs(limit: int = 100) -> List[Dict]:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM actions ORDER BY id DESC LIMIT ?", (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def get_pending_deletes(pending_hours: int = 6) -> List[Dict]:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    from datetime import timedelta
    cutoff = (datetime.utcnow() - timedelta(hours=pending_hours)).isoformat()
    cursor.execute("""
        SELECT * FROM messages 
        WHERE status = 'pending_delete' AND updated_ts < ?
    """, (cutoff,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def get_messages_by_status(status: str, limit: int = 100) -> List[Dict]:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM messages WHERE status = ? ORDER BY created_ts DESC LIMIT ?", (status, limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def create_session(session_id: str, providers: List[str], folders: List[str], date_mode: str, rolling_days: int = None, from_date: str = None, to_date: str = None) -> bool:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    now = datetime.utcnow().isoformat()
    try:
        cursor.execute("ALTER TABLE sessions ADD COLUMN date_mode TEXT")
    except:
        pass
    try:
        cursor.execute("ALTER TABLE sessions ADD COLUMN rolling_days INTEGER")
    except:
        pass
    try:
        cursor.execute("""
            INSERT INTO sessions (id, created_at, providers, folders, range_filter, date_mode, rolling_days, from_date, to_date, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'open')
        """, (session_id, now, json.dumps(providers), json.dumps(folders), date_mode, date_mode, rolling_days, from_date, to_date))
        conn.commit()
        result = True
    except:
        result = False
    conn.close()
    return result


def get_session(session_id: str) -> Optional[Dict]:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM sessions WHERE id = ?", (session_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def get_open_session() -> Optional[Dict]:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM sessions WHERE status = 'open' ORDER BY created_at DESC LIMIT 1")
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def close_session(session_id: str) -> bool:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    cursor.execute("UPDATE sessions SET status = 'closed' WHERE id = ?", (session_id,))
    affected = cursor.rowcount
    conn.commit()
    conn.close()
    return affected > 0


def add_session_item(session_id: str, key: str, provider: str, message_id: str, date: str, classification: str, subject: str, sender: str) -> bool:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT OR IGNORE INTO session_items (session_id, key, provider, message_id, date, classification, subject, sender)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (session_id, key, provider, message_id, date, classification, subject, sender))
        conn.commit()
        result = True
    except:
        result = False
    conn.close()
    return result


def get_session_items(session_id: str, limit: int = 100, provider: str = None, folder: str = None, classification: str = None) -> List[Dict]:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    
    query = "SELECT si.*, m.folder, m.body_text, m.status FROM session_items si LEFT JOIN messages m ON si.key = m.key WHERE si.session_id = ?"
    params = [session_id]
    
    if provider:
        query += " AND si.provider = ?"
        params.append(provider)
    if classification:
        query += " AND si.classification = ?"
        params.append(classification)
    
    query += " ORDER BY si.date DESC LIMIT ?"
    params.append(limit)
    
    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def get_session_item_count(session_id: str) -> Dict[str, int]:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    cursor.execute("SELECT provider, COUNT(*) as count FROM session_items WHERE session_id = ? GROUP BY provider", (session_id,))
    rows = cursor.fetchall()
    conn.close()
    return {row["provider"]: row["count"] for row in rows}


def add_queued_action(key: str, action: str, session_id: str = None, body: str = None) -> int:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    now = datetime.utcnow().isoformat()
    
    parts = key.split(":", 1)
    provider = parts[0] if len(parts) > 1 else ""
    msg_id = parts[1] if len(parts) > 1 else key
    
    meta = {"body": body} if body else {}
    
    cursor.execute("""
        INSERT INTO actions (key, provider, msg_id, action, status, reason, meta_json, ts, session_id)
        VALUES (?, ?, ?, ?, 'queued', '', ?, ?, ?)
    """, (key, provider, msg_id, action, json.dumps(meta), now, session_id))
    action_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return action_id


def get_queued_actions(session_id: str = None, limit: int = 200) -> List[Dict]:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    
    if session_id:
        cursor.execute("SELECT * FROM actions WHERE status = 'queued' AND session_id = ? ORDER BY ts LIMIT ?", (session_id, limit))
    else:
        cursor.execute("SELECT * FROM actions WHERE status = 'queued' ORDER BY ts LIMIT ?", (limit,))
    
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]


def update_action_status(action_id: int, status: str, reason: str = "") -> bool:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    cursor.execute("UPDATE actions SET status = ?, reason = ? WHERE id = ?", (status, reason, action_id))
    affected = cursor.rowcount
    conn.commit()
    conn.close()
    return affected > 0


def link_message_to_session(key: str, session_id: str) -> bool:
    init_db()
    conn = _get_conn()
    cursor = conn.cursor()
    cursor.execute("UPDATE messages SET session_id = ? WHERE key = ?", (session_id, key))
    affected = cursor.rowcount
    conn.commit()
    conn.close()
    return affected > 0
